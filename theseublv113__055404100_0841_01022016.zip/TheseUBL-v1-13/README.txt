You'll find two versions of the common cover for PhD theses of Comue UBL:

1. The LaTeX version is the one up-to-date (supposed to be!).

2. A docx version has been provided by Anthony Goupil, head of schooling of École centrale de Nantes.  It can be used as a base for those who use a word-processor.

   Note that you have to substitute the forme LUNAM logo for the new UBL one.

   CAUTION, depending on the word-processor used, and even on the version, rendering needs to be adjusted based on the reference provided by the LaTeX version.

3. The comments in the LaTeX source code of a thesis have been put into a document named "directives-these-english.pdf".  Reading it is recommanded also to the users of a word-processing software.
